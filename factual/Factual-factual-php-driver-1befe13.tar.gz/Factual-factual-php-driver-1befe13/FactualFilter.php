<?php

 /** This is a refactoring of the Factual Driver by Aaron: https://github.com/Factual/factual-java-driver
 * @author Tyler
 * @package Factual
 * @license Apache 2.0
 */
 
interface FactualFilter {

  public function toJsonStr();

}

?>
