<?php
include_once('osm.utils.php');

$handle = NULL;

//$file = "sm.xml"; // "731.osc.xml"; // "mass200klines.osm"; //"massachusetts.osm";
$innode = FALSE;
$changetype = NULL;
// database variables
$conn = NULL;

/**
 * Take a <node> and decide whether to process it based on it's contents.
 * If it doesn't have any <tag>s, it's not a POI, so ignore.
 * If it only has transportation tags, ignore.
 * Otherwise, pass the XML to a function to process it into a POI PHP object.
 */
function doNodeNode($node) {
  global $goodcategories;
  global $changetype;
  global $handle;

  $ignore = TRUE;
  $xml = simplexml_load_string($node);
  $tags = $xml->tag; // array of <tag> elements
  foreach ( $tags as $tag ) {
    $k = $tag['k'];
    if ( array_search($k, $goodcategories) == TRUE ) {
      $poi = goodNodeToPOI($xml);
      
      if ( $changetype == "DELETE" ) {
        $sources = $poi->getIds();
       
        if ( sizeof(array_count_values($sources)) < 2 ) { // if POI is all OSM data, then delete the whole thing
          POI::deleteDB($poi->id);
        } else { // otherwise, just delete properties with an ID the same as the POI's ID
          POI::deleteDB($poi->id, TRUE);
        }
        
      } elseif ( $changetype == "MODIFY" ) {
        // delete all old OSM  attributes
        POI::deleteDB($poi->id, TRUE);

        // add new ones
        foreach ($poi->labels as &$label) {
          insertPOIObjectFromID($label, $poi->id);
        }
        foreach ($poi->categories as &$cat) {
          insertPOIObjectFromID($cat, $poi->id);
        }
        foreach ($poi->links as &$link) {
          insertPOIObjectFromID($link, $poi->id);
        }

        // see if location needs to be updated
        $poi_orig = POI::loadPOI($poi->id);
        $coords = $poi->location->points[0]->poslist;
        echo "coords are: $coords\n";
        echo "POI ORIG: \n" . echoPOIXML($poi_orig) . "\n";
        if ( ($coords) != ($poi_orig->location->points[0]->poslist) ) {
          $conn = getDBConnection();
          //get uuid of location
          try {
            $locuuid = NULL;
            $sql = "SELECT myid FROM location WHERE id LIKE '" . $poi->id . "' AND deleted is NULL";
            $c = $conn->query($sql);
            if ( $c ) {
              foreach ($c as $row) {
                $locuuid = $row['myid'];
              }
            }
            if ( $locuuid ) {
              $sql = "UPDATE geo SET nativecoords='" . $coords . "'";
              $sql .= ",geompt=ST_GeomFromText('POINT($coords)', 4326) ";
              $sql .= "WHERE parentid = '" . $locuuid . "' AND objname LIKE 'POINT' AND term LIKE 'centroid' AND deleted is NULL";
              $c = $conn->exec($sql);
            } else {
              echo "Error getting location uuid\n";
            }
          } catch (Exception $e) {
            echo "Error updating location: " . $e->getMessage() . "\n";
          }
        }
        
      } elseif ( $changetype == "CREATE" ) {
        $poi->insertDB();
      }
      
      // format for outputting to a file
      // $s = "<" . strtolower($changetype) . ">\n"; 
      // $s .= goodNodeToPOI($xml)->asXML();
      // $s .= "</" . strtolower($changetype) . ">\n";
      // if ( fwrite($handle, $s) === FALSE ) {
      //   echo "Couldn't write to file!\n";
      //   exit;
      // }      
      return;
    }
  }
}

/**
 * Do nothing. OSM doesn't have data in the CDATA
 */
function contents($parser, $data){
}

function startTag($parser, $data, $attribs) {
  global $innode;
  global $nodeelement;
  global $node;
  global $firstchild;
  global $nodecontainsstuff;
  global $changetype;
    
  if ( $data == "NODE" ) {
    $nodeelement = "<node";
    foreach ($attribs as $key=>$value) 
      $nodeelement .= (" " . strtolower($key) . "=\"" . $value . "\"");
    $nodeelement .= ">\n";
    $innode = TRUE;
    $firstchild = TRUE;
    
  // if <node> has any children, they will be tags and we want to consider this a POI
  } else if ( $innode == TRUE ) {
    if ( $firstchild == TRUE ) {
      $node = $nodeelement;
      $nodeelement = "";
      $firstchild = FALSE;
      $nodecontainsstuff = TRUE;
    }
    
    $node .= "<" . strtolower($data);
    foreach ($attribs as $key=>$value) 
      $node .= (" " . strtolower($key) . "=\"" . htmlspecialchars($value,ENT_QUOTES,'UTF-8') . "\"");
    // ENT_XML1 won't work until PHP 5.4
    // echo (" " . strtolower($key) . "=\"" . htmlspecialchars($value,ENT_XML1,'UTF-8') . "\"");
    $node .= "/>\n";
  }
  
  else {
    if ( $data == "MODIFY") {
      $changetype = "MODIFY";
      return;
    } elseif ( $data == "DELETE") {
      $changetype = "DELETE";
      return;
    } elseif ( $data == "CREATE") {
      $changetype = "CREATE";
      return;
    }    
  }
}

function endTag($parser, $data){
  global $innode;
  global $nodeelement;
  global $node;
  global $nodecontainsstuff;

  if ( $data == "NODE" && $nodecontainsstuff) {
    $innode = FALSE;
    $nodecontainsstuff = FALSE;
    $node .= "</" . strtolower($data) . ">\n";
    doNodeNode($node);
  }
}

/**
 * returns the file name of the POIs
 */
function makeGoodChangeNodes($changenodefile) {
  global $osmbasedir;
  global $handle;
  global $conn;
  
  // $outfile = $osmbasedir . "out_change.xml";

  // set up a streaming XML parser
  $xml_parser = xml_parser_create();
  xml_set_element_handler($xml_parser, "startTag", "endTag");
  xml_set_character_data_handler($xml_parser, "contents");

  // open a new file for writing and empty it if it exists
  // if ( !$handle = fopen($outfile, 'w') ) {
  //   echo "Cannot open file ($outfile)\n";
  //   exit;
  // }

  // open the OSM file for reading
  clearstatcache(TRUE, $changenodefile);
  $fp = fopen($changenodefile, "r");
  
  // set up the database connection
  if ( $conn = !getDBConnection() ) {
    echo "Couldn't connect to database for processing changeset.\n";
    exit;
  }

  while ( $data = fread($fp, 4096) ) {
    xml_parse( $xml_parser, $data, feof($fp) ) or 
      die(sprintf('XML ERROR: %s at line %d', 
        xml_error_string(xml_get_error_code($xml_parser)), 
        xml_get_current_line_number($xml_parser)));
  }

  xml_parser_free($xml_parser);

  fclose($fp);
  // fclose($handle);
  // return $outfile;
}

?>
