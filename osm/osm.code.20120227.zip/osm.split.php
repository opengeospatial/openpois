<?php
include_once('../utils.php');
include_once('osm.utils.php');

$basedir = "/Users/rajsingh/workspace/openpoidb";
$fn = "/databases/OSM_Massachusetts/mass40klines.osm"; 
$fn = "/databases/OSM_Massachusetts/mass5mlines.osm"; 
$fn = "/databases/OSM_Massachusetts/massachusetts.osm";
$fn = "/databases/OSM_Italy/italy.osm";
// $fn = "/databases/OSM_England/england.osm";
// $fn = "/databases/OSM_DC/district_of_columbia.osm";
$fn = "/databases/OSM_China/china.osm";
$file = $basedir . $fn;

$d = date('Ymd H:i:sO');
echo "$d: Load of $fn started...\n";

// build directory of temporary files
$d = dirname($file);
$dr = $d . '/tmp';

// delete temp directory if it's there
if ( file_exists($dr) ) {
  shell_exec("rm -r $dr");
}

if ( !mkdir($dr) ) 
  exit("Couldn't make directory $dr\n");

$filesuffix = 1;
$linecounter = 0;
$linemax = 1000000;

$file_handle = fopen($file, "r");
$n = leading_zeros("$filesuffix", 8);
$writetome = fopen($dr . '/osm_' . $n, "w");

while (!feof($file_handle)) {  
  $line = fgets($file_handle);

  if ( strpos($line, '  <node id=') === 0 && substr_compare(trim($line), '/>', -2, 2) === 0) {
    continue;
  }
  
  if ( $linecounter < $linemax || 
      (strpos($line, "</node>") === FALSE && strpos($line, "</way>") === FALSE) ) {
    fwrite($writetome, $line);
    $linecounter++;

  } else {
    fwrite($writetome, $line); //write that last </node> or </way> line
    fwrite($writetome, "</osm>\n"); // close the XML
    fclose($writetome); //then close that file
    flush();
    $filesuffix++;
    $n = leading_zeros("$filesuffix", 8);
    $writetome = fopen($dr.'/osm_'.$n, "w"); // make a new file
    fwrite($writetome, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    fwrite($writetome, "<osm version=\"0.6\" generator=\"osm.load.php\">\n");
    $linecounter = 0; //and start line counting over
  }
}

// clean up
fclose($file_handle);

if ($handle = opendir($dr)) {
   while ( FALSE !== ($entry = readdir($handle)) ) {
     if ( strpos($entry, '.') === 0 ) {
       continue;
     }
     
     $e = $dr . '/' . $entry;
     system("php osm.load.php $e");
   }
}

// delete temp directory if it's there
if ( file_exists($dr) ) {
  shell_exec("rm -r $dr");
}

$d = date('Ymd H:i:sO');
echo "$d: Load of $fn SUCCESS!\n";

?>