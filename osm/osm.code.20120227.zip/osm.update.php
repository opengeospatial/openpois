<?php
include_once('osm.utils.php');
include_once('osm.updatenodes.php');
include_once('../class.poi.php');

/**
 * Get the OSM daily changeset, formatting the dates in 
 * UTC. It should be run after 2am UTC. 
 */
function getChangeSet() {
  global $osmbasedir;
  
  $baseurl = 'http://planet.openstreetmap.org/daily/';
  $downloadfile = $osmbasedir . 'changeset.osc.gz';

  // set the default timezone to use. Available since PHP 5.1
  // $tz = new DateTimeZone(DateTimeZone::UTC);
  date_default_timezone_set('UTC');
  $date = new DateTime();
  $osmfilename = '-' . $date->format('Ymd');

  $oneday = new DateInterval('P1D');
  $yesterday = $date->sub($oneday);
  $osmfilename = $yesterday->format('Ymd') . $osmfilename;
  $osmfilename .= '.osc.gz';
  $osmurl = $baseurl . $osmfilename;

  $fp = fopen($downloadfile, 'w');
  $ch = curl_init($osmurl);
  curl_setopt($ch, CURLOPT_FILE, $fp); // set the downloaded data to go into the file
  curl_setopt($ch, CURLOPT_HEADER, 0);
  curl_setopt($ch, CURLOPT_ENCODING, ''); // let curl un-gzip (DOESN'T WORK!!)
  $data = curl_exec($ch);

  // close cURL resource, and free up system resources
  curl_close($ch);
  fclose($fp);
  // inflate it
  exec('gunzip ' . $downloadfile);
  
  return TRUE;
}


if ( !getChangeSet() ) {
  echo "problem getting changeset file\n";
  exit;
}

$f = $osmbasedir . 'changeset.osc';
makeGoodChangeNodes($f);

?>