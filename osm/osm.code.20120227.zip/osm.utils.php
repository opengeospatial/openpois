<?php

$osmbaseurl = 'http://www.openstreetmap.org';
$osmdataurl = 'http://www.openstreetmap.org/api/0.6/node';
$osmweburl = 'http://www.openstreetmap.org/browse/node';
$osmbasedir = '/Users/rajsingh/workspace/openpoidb/databases/tmp/';
$category_scheme = 'http://wiki.openstreetmap.org/wiki/Map_Features';
$goodcategories = array('leisure','amenity','office','shop','craft','emergency','tourism','historic');

function getOSMAuthor() {
  global $osmbaseurl;
  $a = new POITermType('AUTHOR', 'OSM');
  $a->id = $osmbaseurl;
  return $a;
}

/**
 * Takes an OpenStreetMap <node> and converts to a W3C POI <poi>
 * returns a POI PHP class object
 */
function goodNodeToPOI($xml) {
  global $osmdataurl, $osmweburl, $category_scheme;
  
  // create a POI object
  $osmid = (string)$xml->attributes()->id;
  $p = new POI( $osmid, $osmdataurl );
  $pid = $p->getId();
  
  // author
  // $p->author = getOSMAuthor();
  
  // updated
  // if ( !empty($xml->attributes()->timestamp) ) {
  //   $p->updated = $xml->attributes()->timestamp;
  // }  

  $tags = $xml->tag; // array of <tag> elements
  foreach ( $tags as $tag ) {
    $k = (string)$tag['k'];
    $v = (string)$tag['v'];
    
    if ( $k == 'name' ) {
      $l = new POITermType('LABEL', $k, $v, $category_scheme);
      $l->setBase($osmdataurl);
      $l->setId($osmid);
      $p->addLabel($l);

    } else {
      $c = new POITermType('CATEGORY', $k, NULL, $category_scheme . '#' . $k);
      $c->setScheme($category_scheme);
      $c->setBase($category_scheme);
      $c->setId($v);      
      $p->addCategory($c);
    }
  }
  
  // license
  $l = new POITermType('LICENSE', 'CC-BY-SA', 'Attribution-ShareAlike 2.0 Generic', 'http://creativecommons.org/licenses/');
  $l->setHref('http://creativecommons.org/licenses/by-sa/2.0/');
  $p->setLicense($l);
  
  // links
  $l = new POITermType('LINK', 'via', NULL, 'http://www.iana.org/assignments/link-relations/link-relations.xml');
  $l->setBase($osmdataurl);
  $l->setId($osmid);
  $l->setHref($osmdataurl . '/' . $osmid);
  $p->addLink($l);

  $l = new POITermType('LINK', 'related', NULL, 'http://www.iana.org/assignments/link-relations/link-relations.xml');
  $l->setBase($osmdataurl);
  $l->setId($osmid);
  $l->setHref($osmweburl . '/' . $osmid);
  // $l->setBase($osmdataurl);
  $p->addLink($l);

  // location!!!
  if ( !empty($xml->attributes()->lat) && !empty($xml->attributes()->lon) ) {
    $loc = new Location();
    $loc->setBase($osmdataurl);
    $loc->setId($osmid);

    // points
    $poslist = (string)$xml->attributes()->lat . ' ' . (string)$xml->attributes()->lon;
    $geom = new Geom('point', 'Point', $poslist, 'centroid');
    // $geom->author = getOSMAuthor();
    $loc->addPointGeom($geom);
    $p->location = $loc;
  }

  return $p;
}

?>